# timetravel10_hash
Python module for the timetravel10 hash function

## Prerequisites

```
sudo apt-get install python-dev
```

## Installation

To install this module, clone this repository and run:

```
python setup.py install
```
